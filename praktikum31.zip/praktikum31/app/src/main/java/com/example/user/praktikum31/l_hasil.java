package com.example.user.praktikum31;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.TextView;

public class l_hasil extends AppCompatActivity {
    private String kr_nama= "nama";
    private String hari_lahir= "hari";
    private String bulan_lahir= "bulan";
    private String tahun_lahir= "tahun";

    TextView tx_nama;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l_hasil);
        Bundle extras=getIntent().getExtras();
        String nama=extras.getString(kr_nama);
        String hari=extras.getString(hari_lahir);
        String bulan=extras.getString(bulan_lahir);
        String tahun=extras.getString(tahun_lahir);

        String[] data_bulan= {"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus",
                "September","Oktober","November","Desember"};
        int int_bulan=Integer.valueOf(bulan);
        int tahun_sekarang=2019;
        int usia=tahun_sekarang-Integer.valueOf(tahun);
        tx_nama=(TextView)findViewById(R.id.out_nama);

        tx_nama.setText("Nama Anda \t\t\t:"+nama+"\n" +
                "Tanggal Lahir \t:"+hari+"-"+data_bulan[int_bulan]+"-"+tahun+
                "\nusia\t\t\t\t\t\t:"+usia+" tahun");
    }
}
