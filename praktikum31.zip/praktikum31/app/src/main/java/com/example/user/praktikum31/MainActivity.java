package com.example.user.praktikum31;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed_nama;
    DatePicker dt_tgl;
    private String kr_nama= "nama";
    private String hari_lahir= "hari";
    private String bulan_lahir= "bulan";
    private String tahun_lahir= "tahun";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed_nama=(EditText)findViewById(R.id.nama);
        dt_tgl=(DatePicker)findViewById(R.id.datePicker);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void detail(View view) {
        Intent pn=new Intent(MainActivity.this,l_hasil.class);
        pn.putExtra(kr_nama,ed_nama.getText().toString());
        int day=dt_tgl.getDayOfMonth();
        int bulan=dt_tgl.getMonth();
        int tahun=dt_tgl.getYear();
        pn.putExtra(hari_lahir,""+day);
        pn.putExtra(bulan_lahir,""+bulan);
        pn.putExtra(tahun_lahir,""+tahun);

        startActivity(pn);
    }
}
